import React from 'react';

import {LoadingProgress} from '../LoadingProgress';

describe('<LoadingProgress />', () => {});
