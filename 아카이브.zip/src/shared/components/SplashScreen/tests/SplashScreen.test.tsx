import React from 'react';

import {SplashScreen} from '../SplashScreen';

describe('<SplashScreen />', () => {});
