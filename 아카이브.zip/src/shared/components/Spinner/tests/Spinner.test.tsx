import React from 'react';

import {Spinner} from '../Spinner';

describe('<Spinner />', () => {});
