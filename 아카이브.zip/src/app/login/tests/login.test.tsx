import React from 'react';

import {login} from '../page';

describe('<login />', () => {});
