import React from 'react';

import {join} from '../page';

describe('<join />', () => {});
