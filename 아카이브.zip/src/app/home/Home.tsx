import styles from './Home.module.scss';
import { SearchSection, EventSlider, PopularHobbies } from "../../features/home/components";

const events = [
  {
    title: '놀라운 특가 등장! 국내여행 오픈런',
    description: '매주 월·목 오전 10시 오픈!',
    image: 'https://tailwindcss.com/plus-assets/img/ecommerce-images/home-page-02-edition-03.jpg',
  },
  {
    title: '놀라운 특가 등장! 국내여행 오픈런',
    description: '매주 월·목 오전 10시 오픈!',
    image: 'https://tailwindcss.com/plus-assets/img/ecommerce-images/home-page-02-edition-03.jpg',
  },
  {
    title: '놀라운 특가 등장! 국내여행 오픈런',
    description: '매주 월·목 오전 10시 오픈!',
    image: 'https://tailwindcss.com/plus-assets/img/ecommerce-images/home-page-02-edition-03.jpg',
  },
  {
    title: '놀라운 특가 등장! 국내여행 오픈런',
    description: '매주 월·목 오전 10시 오픈!',
    image: 'https://tailwindcss.com/plus-assets/img/ecommerce-images/home-page-02-edition-03.jpg',
  },
  {
    title: '놀라운 특가 등장! 국내여행 오픈런',
    description: '매주 월·목 오전 10시 오픈!',
    image: 'https://tailwindcss.com/plus-assets/img/ecommerce-images/home-page-02-edition-03.jpg',
  },
]
export interface HomeProps {
  prop?: string;
}

export default function Home() {
  return (
    <div>
      <section className="bg-orange-100 py-16 px-4 text-center">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            내 주변, 내 취미 친구 찾기
          </h1>
          <p className="text-lg text-gray-700 mb-8">
            직접 취미 모임을 만들고, 근처에서 함께 즐겨요!
          </p>
          <div className="flex justify-center gap-4 flex-wrap">
            <a href="/my-hobbies/create" className="bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-700">
              취미 만들기
            </a>
            <a href="/search" className="bg-white border border-blue-600 text-blue-600 px-6 py-3 rounded-xl font-semibold hover:bg-blue-50">
              주변 취미 둘러보기
            </a>
          </div>
        </div>
      </section>
      <SearchSection />
      <EventSlider slides={events}/>
      <PopularHobbies/>
      <main className={`p-4 rounded-lg`}>
        {/* 카드 컴포넌트 리스트도 여기에 추가할 수 있음 */}
      </main>
    </div>
  );
}