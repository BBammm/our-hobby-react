export default function BookmarkedHobbyPage() {
  return <div>내 북마크 이력</div>
}