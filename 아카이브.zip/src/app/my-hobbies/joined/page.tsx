export default function JoinedHobbyPage() {
  return <div>내가 가입한 취미</div>
}