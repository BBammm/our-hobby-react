export default function ActivityHobbyPage() {
  return <div>내 활동 이력</div>
}