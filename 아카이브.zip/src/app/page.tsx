import Home from "./home/Home";

export default function Page() {
  return <Home />;
}