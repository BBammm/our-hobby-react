import React from 'react';

import {MapLocationSelector} from '../MapLocationSelector';

describe('<MapLocationSelector />', () => {});
