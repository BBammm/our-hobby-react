import React from 'react';

import {SearchSection} from '../SearchSection';

describe('<SearchSection />', () => {});
