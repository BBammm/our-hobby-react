export {default as SearchSection} from './SearchSection/SearchSection';
export {default as EventSlider} from './EventSlider/EventSlider';
export {default as PopularHobbies} from './PopularHobbies/PopularHobbies';
