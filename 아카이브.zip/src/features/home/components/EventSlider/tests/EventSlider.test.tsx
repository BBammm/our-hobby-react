import React from 'react';

import {EventSlider} from '../EventSlider';

describe('<EventSlider />', () => {});
