import React from 'react';

import {PopularHobbies} from '../PopularHobbies';

describe('<PopularHobbies />', () => {});
