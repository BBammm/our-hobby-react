import React from 'react';

import {CardItem} from '../CardItem';

describe('<CardItem />', () => {});
